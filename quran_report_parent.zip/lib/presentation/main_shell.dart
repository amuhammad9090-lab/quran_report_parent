import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../core/utils/responsive.dart';
import '../data/repositories/parent_note_repository.dart';
import '../data/repositories/report_repository.dart';
import '../data/repositories/weekly_recap_repository.dart';
import '../data/services/progress_calculation_service.dart';
import '../providers/auth_provider.dart';
import '../providers/dashboard_provider.dart';
import '../providers/hafalan_provider.dart';
import '../providers/parent_note_provider.dart';
import '../providers/weekly_recap_provider.dart';
import 'screens/dashboard/dashboard_screen.dart';
import 'screens/history/history_screen.dart';
import 'screens/settings/settings_screen.dart';

/// Shell navigasi utama portal orang tua — 3 tab (Beranda, Perkembangan,
/// Pengaturan). Tab "Hafalan" sengaja DIHAPUS sebagai layar terpisah — progress
/// per-juz sekarang tampil sebagai kartu interaktif di Beranda (lihat
/// [HafalanProvider]) dan detail riwayatnya di tab Perkembangan. Sengaja
/// juga TIDAK membawa seluruh navigation app guru (Laporan, Folder,
/// Statistik, Export, dst) — portal ini harus terasa ringan, cuma yang
/// relevan buat orang tua.
///
/// Tab ke-3 SEBELUMNYA "Profil" — sekarang "Pengaturan" (`SettingsScreen`,
/// isinya cuma tema + tentang aplikasi). Konten Profil lama (Data Santri,
/// Ganti Password, Logout, foto profil) pindah ke `AccountScreen`, diakses
/// dengan TAP bulatan akun di hero Beranda (lihat `_DashboardHero` di
/// `dashboard_screen.dart`) — bukan tab tersendiri lagi.
///
/// `NavigationBar` di sini nanti otomatis ambil style dari `AppTheme`
/// (height 72, indicator radius 16, dll — sudah didefinisikan di
/// navigationBarTheme yang di-share dari app guru) begitu STEP 4+ jalan.
class MainShell extends StatelessWidget {
  const MainShell({super.key});

  @override
  Widget build(BuildContext context) {
    // MainShell hanya pernah ditampilkan setelah AuthProvider.status ==
    // loggedIn (lihat _AuthGate di app.dart), jadi currentStudent selalu
    // sudah terisi di sini — DashboardProvider dibuat SATU KALI untuk
    // seluruh sesi (bukan per-tab), supaya data tidak di-fetch ulang
    // tiap pindah tab Dashboard/Riwayat.
    final student = context.read<AuthProvider>().currentStudent!;
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (ctx) => DashboardProvider(
            reportRepository: ctx.read<ReportRepository>(),
          )..load(student),
        ),
        // <-- BARU: HafalanProvider (progress per-juz, sudah ada sejak
        // STEP 6 tapi belum pernah di-wire ke UI) — dipasang lewat
        // ChangeNotifierProxyProvider supaya otomatis re-compute begitu
        // DashboardProvider.records selesai load, TANPA query Firestore
        // tambahan (murni agregasi dari records yang sudah di-fetch di
        // atas). Dipakai kartu "Progress Hafalan" interaktif di Beranda.
        ChangeNotifierProxyProvider<DashboardProvider, HafalanProvider>(
          create: (ctx) => HafalanProvider(
            progressService: ctx.read<ProgressCalculationService>(),
          ),
          update: (ctx, dash, hafalan) {
            final provider = hafalan ??
                HafalanProvider(progressService: ctx.read<ProgressCalculationService>());
            if (!dash.isLoading) provider.computeFrom(dash.records);
            return provider;
          },
        ),
        // Provider terpisah dari DashboardProvider (yang murni baca) —
        // ini satu-satunya bagian sesi orang tua yang menulis data,
        // lihat catatan arsitektur di `parent_note_repository.dart`.
        ChangeNotifierProvider(
          create: (ctx) => ParentNoteProvider(
            repository: ctx.read<ParentNoteRepository>(),
            student: student,
          )..loadRecent(),
        ),
        // <-- BARU: rekap pekanan yang di-deploy guru dari
        // GenerateRekapPekananScreen (app guru) — ditampilkan sebagai
        // section di HistoryScreen.
        ChangeNotifierProvider(
          create: (ctx) => WeeklyRecapProvider(
            repository: ctx.read<WeeklyRecapRepository>(),
            student: student,
          )..load(),
        ),
      ],
      child: const _MainShellBody(),
    );
  }
}

class _MainShellBody extends StatefulWidget {
  const _MainShellBody();

  @override
  State<_MainShellBody> createState() => _MainShellBodyState();
}

class _MainShellBodyState extends State<_MainShellBody> {
  int _index = 0;

  static const _destinations = [
    (icon: Icons.home_rounded, label: 'Beranda'),
    (icon: Icons.trending_up_rounded, label: 'Perkembangan'),
    (icon: Icons.settings_rounded, label: 'Pengaturan'),
  ];

  void _goToPerkembangan() => setState(() => _index = 1);

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(onSeeAllActivity: _goToPerkembangan),
      const HistoryScreen(),
      const SettingsScreen(),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= kDesktopBreakpoint;

        // Body dibungkus ResponsiveContentWidth supaya di layar lebar
        // (desktop/tablet) konten tetap nyaman dibaca, tidak melebar
        // penuh sampai tepi layar. Tiap screen (Beranda/Perkembangan/dst)
        // sudah bawa Scaffold sendiri (perlu AppBar per layar), jadi
        // dibungkus di sini lewat Builder supaya AppBar tetap full-width
        // tapi body-nya yang dibatasi.
        //
        // Semua tab TETAP mounted (Stack, bukan swap widget) supaya state
        // tiap tab (scroll position, filter periode di Perkembangan) tidak
        // hilang waktu pindah-pindah — cuma opacity yang di-crossfade
        // secara halus, dan IgnorePointer mencegah tab yang sedang
        // tersembunyi ikut menerima tap.
        final content = Stack(
          children: [
            for (int i = 0; i < screens.length; i++)
              Positioned.fill(
                child: IgnorePointer(
                  ignoring: i != _index,
                  child: AnimatedOpacity(
                    opacity: i == _index ? 1 : 0,
                    duration: const Duration(milliseconds: 220),
                    curve: Curves.easeOut,
                    child: screens[i],
                  ),
                ),
              ),
          ],
        );

        if (!isWide) {
          return Scaffold(
            body: content,
            bottomNavigationBar: NavigationBar(
              selectedIndex: _index,
              onDestinationSelected: (i) => setState(() => _index = i),
              destinations: [
                for (final d in _destinations)
                  NavigationDestination(icon: Icon(d.icon), label: d.label),
              ],
            ),
          );
        }

        // Layar lebar: NavigationRail di kiri (menggantikan bottom nav),
        // sama komponennya cuma orientasi beda — bukan navigasi baru.
        return Scaffold(
          body: Row(
            children: [
              NavigationRail(
                selectedIndex: _index,
                onDestinationSelected: (i) => setState(() => _index = i),
                labelType: NavigationRailLabelType.all,
                destinations: [
                  for (final d in _destinations)
                    NavigationRailDestination(icon: Icon(d.icon), label: Text(d.label)),
                ],
              ),
              const VerticalDivider(width: 1),
              Expanded(child: content),
            ],
          ),
        );
      },
    );
  }
}
