import 'dart:async';

import 'package:flutter/material.dart';

import '../data/models/enums.dart';
import '../data/models/santri_record.dart';
import '../data/models/student.dart';
import '../data/repositories/report_repository.dart';

/// Menyiapkan data dashboard untuk SATU santri (santri yang sedang login,
/// dari [ParentAccessScope]). Read-only murni — tidak ada method
/// mutate/create/delete sama sekali.
class DashboardProvider extends ChangeNotifier {
  final ReportRepository reportRepository;

  DashboardProvider({required this.reportRepository});

  bool isLoading = false;
  // <-- BARU: sebelumnya gak ada try/catch di load() -- kalau query
  // Firestore gagal (index belum jadi, rules, dll), isLoading NGGAK
  // PERNAH balik ke false, jadi UI muter selama-lamanya tanpa pesan
  // error apa pun. Sekarang error ke-tangkep & disimpan di [error].
  String? error;
  List<SantriRecord> records = [];

  StreamSubscription<List<SantriRecord>>? _subscription;

  /// Mulai LISTEN live ke laporan [student] (bukan fetch sekali lagi) —
  /// return Future yang selesai begitu snapshot PERTAMA datang (atau
  /// gagal), supaya pemanggil yang masih await pola lama tetap jalan
  /// normal. Setelah itu, listener tetap aktif di background: begitu
  /// guru submit/edit laporan baru, [records] ke-update sendiri dan
  /// [notifyListeners] dipanggil lagi — makanya "Catatan Guru", progress
  /// hafalan, insight, dst di Beranda otomatis real-time tanpa orang tua
  /// perlu refresh/buka-tutup app.
  Future<void> load(Student student) {
    isLoading = true;
    error = null;
    notifyListeners();

    final completer = Completer<void>();
    _subscription?.cancel();
    _subscription = reportRepository.watchRecordsForStudent(student).listen(
      (data) {
        records = data;
        isLoading = false;
        error = null;
        notifyListeners();
        if (!completer.isCompleted) completer.complete();
      },
      onError: (Object e, StackTrace st) {
        // debugPrint biar tetap kelihatan jelas di console browser (F12),
        // gampang dibedain dari noise log Firebase yang lain.
        debugPrint('DashboardProvider.load GAGAL: $e\n$st');
        error = e.toString();
        records = [];
        isLoading = false;
        notifyListeners();
        if (!completer.isCompleted) completer.complete();
      },
    );
    return completer.future;
  }

  @override
  void dispose() {
    _subscription?.cancel();
    super.dispose();
  }

  /// Laporan paling baru (records sudah terurut terbaru dulu dari
  /// repository), null kalau belum pernah ada laporan sama sekali.
  SantriRecord? get latest => records.isEmpty ? null : records.first;

  /// Catatan guru dari laporan terakhir yang punya catatan (bukan cuma
  /// laporan paling baru — kalau laporan terakhir kebetulan tidak diisi
  /// catatan, ambil catatan terbaru yang tersedia).
  String? get latestCatatanGuru => latestRecordWithCatatan?.catatan;

  /// Laporan (lengkap dengan tanggalnya) yang jadi sumber
  /// [latestCatatanGuru] — dipakai buat nampilin "catatan ini dari hari
  /// apa" di kartu Catatan Guru, bukan cuma teksnya doang.
  SantriRecord? get latestRecordWithCatatan {
    for (final r in records) {
      if (r.catatan != null && r.catatan!.trim().isNotEmpty) return r;
    }
    return null;
  }

  /// Distribusi `keterangan` (Hadir/Sakit/Izin/dst) dari SELURUH laporan
  /// yang ada — ini satu-satunya data kehadiran yang benar-benar ada di
  /// app guru (per-laporan, bukan rekap kehadiran harian terpisah), jadi
  /// dipakai apa adanya, bukan mengarang sistem kehadiran baru.
  Map<Keterangan, int> get keteranganDistribution {
    final map = <Keterangan, int>{};
    for (final r in records) {
      map[r.keterangan] = (map[r.keterangan] ?? 0) + 1;
    }
    return map;
  }

  double keteranganRatio(Keterangan k) {
    if (records.isEmpty) return 0;
    return (keteranganDistribution[k] ?? 0) / records.length;
  }

  /// % laporan yang santrinya HADIR secara fisik, dari seluruh laporan —
  /// dipakai untuk card ringkasan "Kehadiran" di dashboard.
  ///
  /// PENTING (sinkron dengan app guru — lihat `records_provider.dart`
  /// `totalHadir`): "hadir" DI SINI BUKAN cuma `Keterangan.hadir`, tapi
  /// juga 3 keterangan "sanksi tanpa setoran" (`tidakSetoran`,
  /// `tidakTahsin`, `tidakMurojaah`, lihat `Keterangan.isSanksiTanpaSetoran`
  /// di enums.dart) — santri yang keterangannya itu SECARA FISIK hadir,
  /// cuma nggak setor/tahsin/murojaah (males/ketiduran/dll), beda dari
  /// Izin Sakit/Izin/Izin Lomba/Izin Pelatihan/Alpa yang memang nggak
  /// hadir. Kalau di sini cuma dihitung `Keterangan.hadir` saja, angka
  /// Kehadiran orang tua akan lebih RENDAH dari yang guru lihat di app
  /// guru untuk santri yang sama — jadi harus dijaga tetap sama definisi.
  double get kehadiranRatio {
    if (records.isEmpty) return 0;
    final hadirCount = records
        .where((r) => r.keterangan == Keterangan.hadir || r.keterangan.isSanksiTanpaSetoran)
        .length;
    return hadirCount / records.length;
  }

  /// Laporan Tahsin (murni atau bagian dari Tahsin+Tahfizh) PALING BARU
  /// sepanjang riwayat — sumber ringkasan "Tahsin Terakhir" di hero
  /// Beranda. Sengaja tidak dibatasi ke pekan berjalan saja (beda dari
  /// [barisTercapaiPekanIni]) karena Tahsin tidak selalu diisi tiap
  /// pertemuan — kalau dibatasi ke pekan ini, chip-nya sering kosong
  /// padahal ada progres Tahsin dari pekan sebelumnya yang masih relevan
  /// ditampilkan. [SantriRecord.tahsinSummaryText] sendiri yang nentuin
  /// format WAFA (level+halaman) atau Tilawah (surah+ayat), sesuai apa
  /// yang guru input — bukan diasumsikan WAFA melulu.
  SantriRecord? get latestTahsinRecord {
    for (final r in records) {
      if (r.status == HafalanStatus.tahsin ||
          r.status == HafalanStatus.tahsinTahfizh) {
        return r;
      }
    }
    return null;
  }

  /// Total baris tahfizh yang tercapai sepanjang riwayat laporan
  /// (agregat totalBaris semua laporan status Tahfizh/Tahsin+Tahfizh).
  /// Ini angka MENTAH dari data existing (bukan persentase — persentase
  /// per-juz baru dihitung di STEP 6, lihat ProgressCalculationService).
  int get totalBarisTercapai =>
      records.fold<int>(0, (sum, r) => sum + (r.totalBaris ?? 0));

  // ---------------------------------------------------------------------
  // Rekap Pekanan — dipakai buat banner Dashboard + card "Baris Pekan
  // Ini" / "Progres Hafalan" / "Rekap Terakhir". Pekan berjalan = Senin
  // 00:00 s/d Minggu 23:59 (pekan kalender, Senin hari pertama). Ini
  // CUMA soal kapan pekan itu sendiri mulai/berakhir — beda dari kapan
  // guru biasanya "nutup"/merampungkan rekapnya (Jumat/Sabtu), yang
  // otomatis kelihatan dari [tanggalRekapTerakhirPekanIni] di bawah.
  // ---------------------------------------------------------------------

  DateTime get _weekStart {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    return today.subtract(Duration(days: today.weekday - 1));
  }

  DateTime get _weekEnd => _weekStart.add(const Duration(days: 6));

  bool _isInCurrentWeek(DateTime tanggal) {
    final d = DateTime(tanggal.year, tanggal.month, tanggal.day);
    return !d.isBefore(_weekStart) && !d.isAfter(_weekEnd);
  }

  /// Subset [records] yang tanggalnya jatuh di pekan berjalan, tetap
  /// terurut terbaru dulu.
  List<SantriRecord> get recordsThisWeek =>
      records.where((r) => _isInCurrentWeek(r.tanggal)).toList();

  /// Total baris Tahfizh yang tercapai DI PEKAN BERJALAN SAJA — beda
  /// dari [totalBarisTercapai] yang akumulasi sepanjang riwayat. Ini
  /// yang dibandingkan ke target mingguan per halaqoh
  /// ([weeklyTargetBarisForHalaqoh]) buat card "Progres Hafalan", dan
  /// ditampilkan mentah di card "Baris Pekan Ini" + banner Dashboard.
  int get barisTercapaiPekanIni =>
      recordsThisWeek.fold<int>(0, (sum, r) => sum + (r.totalBaris ?? 0));

  /// Tanggal laporan PALING BARU di pekan berjalan — null kalau belum
  /// ada laporan sama sekali di pekan ini. Dipakai buat card "Rekap
  /// Terakhir" (biasanya jatuh Jumat/Sabtu, tergantung guru).
  DateTime? get tanggalRekapTerakhirPekanIni {
    if (recordsThisWeek.isEmpty) return null;
    return recordsThisWeek.map((r) => r.tanggal).reduce((a, b) => a.isAfter(b) ? a : b);
  }

  // ---------------------------------------------------------------------
  // Perbandingan pekan ini vs pekan lalu — SEMUA dari [records] yang
  // sudah ter-load sekali per sesi (tidak ada query tambahan). Dipakai
  // untuk kartu "dibanding pekan lalu" di Beranda.
  // ---------------------------------------------------------------------

  DateTime get _prevWeekStart => _weekStart.subtract(const Duration(days: 7));
  DateTime get _prevWeekEnd => _weekStart.subtract(const Duration(days: 1));

  bool _isInPreviousWeek(DateTime tanggal) {
    final d = DateTime(tanggal.year, tanggal.month, tanggal.day);
    return !d.isBefore(_prevWeekStart) && !d.isAfter(_prevWeekEnd);
  }

  /// Subset [records] pekan SEBELUM pekan berjalan.
  List<SantriRecord> get recordsPreviousWeek =>
      records.where((r) => _isInPreviousWeek(r.tanggal)).toList();

  int get barisTercapaiPekanLalu =>
      recordsPreviousWeek.fold<int>(0, (sum, r) => sum + (r.totalBaris ?? 0));

  /// Selisih baris pekan ini vs pekan lalu. Null kalau pekan lalu belum
  /// ada laporan sama sekali (dibandingkan ke 0 tidak adil/menyesatkan —
  /// bisa jadi santrinya baru mulai dilaporkan pekan ini).
  int? get barisDeltaVsPekanLalu {
    if (recordsPreviousWeek.isEmpty) return null;
    return barisTercapaiPekanIni - barisTercapaiPekanLalu;
  }

  // ---------------------------------------------------------------------
  // Insight Minggu Ini — kalimat pendek yang disimpulkan LANGSUNG dari
  // data existing di atas (tidak ada data yang dikarang). Maksimal 3
  // insight, diurutkan dari yang paling relevan/actionable.
  // ---------------------------------------------------------------------

  List<DashboardInsight> get insights {
    if (records.isEmpty) return const [];
    final list = <DashboardInsight>[];

    final delta = barisDeltaVsPekanLalu;
    if (delta != null && delta != 0) {
      list.add(DashboardInsight(
        icon: delta > 0 ? Icons.trending_up_rounded : Icons.trending_down_rounded,
        positive: delta > 0,
        text: delta > 0
            ? 'Naik $delta baris dibanding pekan lalu — pertahankan ritmenya.'
            : 'Turun ${delta.abs()} baris dibanding pekan lalu. Ajak ananda murojaah lebih rutin.',
      ));
    } else if (delta == null && barisTercapaiPekanIni > 0) {
      list.add(DashboardInsight(
        icon: Icons.auto_awesome_rounded,
        positive: true,
        text: 'Pekan pertama dengan laporan — $barisTercapaiPekanIni baris tercatat.',
      ));
    }

    final thisWeekAlpaIzin = recordsThisWeek
        .where((r) =>
            r.keterangan != Keterangan.hadir && !r.keterangan.isSanksiTanpaSetoran)
        .length;
    if (thisWeekAlpaIzin > 0) {
      list.add(DashboardInsight(
        icon: Icons.event_busy_rounded,
        positive: false,
        text: thisWeekAlpaIzin == 1
            ? 'Ada 1 pertemuan pekan ini dengan status izin/tidak hadir.'
            : 'Ada $thisWeekAlpaIzin pertemuan pekan ini dengan status izin/tidak hadir.',
      ));
    }

    final rekapTerakhir = tanggalRekapTerakhirPekanIni;
    if (rekapTerakhir == null && records.isNotEmpty) {
      final lastAny = records.first.tanggal;
      final days = DateTime.now().difference(lastAny).inDays;
      if (days >= 7) {
        list.add(DashboardInsight(
          icon: Icons.info_outline_rounded,
          positive: false,
          text: 'Belum ada laporan baru dalam $days hari terakhir.',
        ));
      }
    }

    if (list.isEmpty && kehadiranRatio >= 0.9 && records.length >= 3) {
      list.add(DashboardInsight(
        icon: Icons.emoji_events_rounded,
        positive: true,
        text: 'Kehadiran ananda sangat konsisten, ${(kehadiranRatio * 100).toStringAsFixed(0)}% sepanjang riwayat.',
      ));
    }

    return list.take(3).toList();
  }
}

/// Satu baris insight yang tampil di kartu "Insight Minggu Ini" —
/// [positive] menentukan warna (hijau/amber), bukan makna wajib
/// baik/buruk (mis. "izin sakit" tetap netral-informatif).
class DashboardInsight {
  final IconData icon;
  final String text;
  final bool positive;
  const DashboardInsight({required this.icon, required this.text, required this.positive});
}
